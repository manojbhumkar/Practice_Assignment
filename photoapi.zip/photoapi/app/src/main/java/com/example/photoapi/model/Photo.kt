package com.example.photoapi.model


data class Photo(
    val img_id: Int,
    val title: String,
    val url: String
)
