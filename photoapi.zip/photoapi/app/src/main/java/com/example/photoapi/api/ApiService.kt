package com.example.photoapi.api

 import com.example.photoapi.model.Photo
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {

    @GET("photos")
    fun getPhotos(): Call<List<Photo>>
}
